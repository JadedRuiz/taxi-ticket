import $ from 'jquery';
import Swal from 'sweetalert2';

$(window).on("load", function() {
    
});

$(document).on("click","#btnOperador",function() {
    $(".btnModalOperador").click();
});