<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Administrativo</title>
    
    <?php echo app('Illuminate\Foundation\Vite')(['public/sass/app.scss','public/js/app.js']); ?>
    <?php if(isset($entries)): ?>
        <?php echo app('Illuminate\Foundation\Vite')($entries); ?>  
    <?php endif; ?>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('favicon.png')); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;1,100;1,200;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/2.1.6/css/dataTables.bootstrap5.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/3.1.2/css/buttons.bootstrap5.css">
</head>
<body>
    <header id="page-topbar">
        <div class="navbar-header">
            <div class="img-header d-flex">
                <div class="navbar-brand-box">
                    <a class="logo logo-dark">
                        <span class="logo-lg">
                            <img src="<?php echo e(asset($userData->logo_path)); ?>" alt="" width="150">
                        </span>
                    </a>
                </div>
            </div>
            <div class="d-flex">
                <div class="dropdown">
                    <div class="info-dropdown d-flex align-items-center" data-bs-toggle="dropdown" aria-expanded="false">
                        <div class="img-admin">
                            <img src="<?php echo e(asset('img/logo-admin.png')); ?>" width="35">
                        </div>
                        <p class="my-0"><?php echo e($userData->usuario); ?></p>
                        <span class="d-flex align-items-center"><i class="fa fa-chevron-down" aria-hidden="true"></i></span>
                    </div>
                    <ul class="dropdown-menu">
                        <li>
                            <a class="dropdown-item d-flex align-items-center" href="<?php echo e(route('auth.logout')); ?>">
                                <span class="uil--sign-out-alt"></span>
                                &nbsp; Cerrar sesión
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="top-nav">
            <nav class="navbar navbar-light navbar-expand-lg">
                <div class="collapse navbar-collapse" id="topnav-menu-content">
                    <ul class="navbar-nav">
                        <?php $__currentLoopData = $userData->menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="nav-item">
                                <a class="nav-link active" href="<?php echo e(route($menu->ruta)); ?>">
                                <span class="<?php echo e($menu->icono); ?>"></span> &nbsp; <?php echo e($menu->titulo); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        
                    </ul>
                </div>
            </nav>
        </div>
    </header>
    <section class="contenido">
        <?php echo e($slot); ?>

    </section>
    
    <?php echo e($scripts); ?>

</body>
</html><?php /**PATH C:\Users\PC WHITE HORSE\OneDrive\Documentos\Jaded\Proyectos\Inge\Laravel\taxi-ticket\resources\views/components/layout.blade.php ENDPATH**/ ?>