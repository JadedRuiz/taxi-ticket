<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['userData' => $user,'entries' => $entries]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['user-data' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user),'entries' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($entries)]); ?>
    <div class="page-content">
        <div class="page-title-box d-flex align-items-center justify-content-between">
            <h4 class="mb-0">Página Vehiculos</h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item">Admin</li>
                    <li class="breadcrumb-item active">Vehiculos</li>
                </ol>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Administrador de vehiculos</h4>
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <p class="card-title-desc">En este módulo podrás agregar o modificar un vehiculo y sus operadores.</p>
                            <button class="btn btn-sm btn-success btnAdd" style="padding-bottom: 0px;">
                                <span class="mdi--truck-plus"></span>
                            </button>
                        </div>
                        <div id="datatable_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                            <div class="row">
                                <div class="col-sm-12">
                                    <table id="datatable" class="table table-striped dataTable display" style="width: 100%;">
                                        <thead>
                                            <tr role="row">
                                                <th class="sorting_asc" tabindex="0" aria-controls="datatable" rowspan="1" colspan="1" style="width: 200px;">Fotografia</th>
                                                <th class="sorting_asc" tabindex="0" aria-controls="datatable" rowspan="1" colspan="1" style="width: 200px;">Vehiculo</th>
                                                <th class="sorting_asc" tabindex="0" aria-controls="datatable" rowspan="1" colspan="1" style="width: 125px; vertical-align: middle" >Marca & Modelo</th>
                                                <th class="sorting_asc text-center" tabindex="0" aria-controls="datatable" rowspan="1" colspan="1" style="width: 100px;">No. Operadores</th>
                                                <th class="sorting_asc" tabindex="0" aria-controls="datatable" rowspan="1" colspan="1" style="width: 125px;">Estatus</th>
                                                <th class="sorting_asc text-center" tabindex="0" aria-controls="datatable" rowspan="1" colspan="1" style="width: 167px;">Acciones</th>
                                            </tr>
                                        </thead>
                                        <tbody class="table-vehiculos">
                                          <?php if($vehiculos["ok"]): ?>
                                            <?php $__currentLoopData = $vehiculos["data"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehiculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <tr>
                                                <td>
                                                  <?php if($vehiculo->namespace == "image"): ?> 
                                                    <img src="<?php echo e(asset($vehiculo->path)); ?>" width="60" height="50">
                                                  <?php elseif($vehiculo->namespace == "url"): ?>
                                                    <img src="<?php echo e($vehiculo->path); ?>" width="60" height="50">
                                                  <?php else: ?>
                                                    <img src="<?php echo e(asset('/img/Image_not_available.png')); ?>" width="80" height="50">
                                                  <?php endif; ?>
                                                </td>
                                                <td><?php echo e($vehiculo->vehiculo); ?></td>
                                                <td><?php echo e($vehiculo->marca); ?> (<?php echo e($vehiculo->modelo); ?>)</td>
                                                <td class="text-center">
                                                  <?php echo e($vehiculo->no_operadores); ?> &nbsp;&nbsp;
                                                  <button class="btn btn-sm btn-success text-white" style="padding-bottom: 0px;" id="btnOperador">
                                                    <span class="ic--baseline-group-add"></span>
                                                  </button>
                                                </td>
                                                <td><?php echo e($vehiculo->activo == 1 ? 'En circulación' : 'No circulado'); ?></td>
                                                <td class="text-center">
                                                  <button class="btn btn-sm btn-warning text-white editVehiculo" style="padding-bottom: 0px;" data-attr="<?php echo e($vehiculo->id_vehiculo); ?>">
                                                    <span class="ic--baseline-edit"></span>
                                                  </button>
                                                </td>
                                              </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div> 
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Operadores -->
    <?php echo $__env->make('components.modales.modal_vehiculo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Modal Operador -->
     <?php echo $__env->make('components.modales.modal_operador',$operadores, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

     <?php $__env->slot('scripts', null, []); ?> 
        <script>
            window.routes = {
                'guardarVehiculo' : '<?php echo e(route('admin.api.guardarVehiculo')); ?>',
                'getVehiculoId' : '<?php echo e(route('admin.api.getVehiculoId')); ?>'
            }
        </script>
     <?php $__env->endSlot(); ?> 
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\PC WHITE HORSE\OneDrive\Documentos\Jaded\Proyectos\Inge\Laravel\taxi-ticket\resources\views/admin/Vehiculos.blade.php ENDPATH**/ ?>