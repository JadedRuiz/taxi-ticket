<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ViajeController;
use App\Http\Controllers\DestinoController;

Route::get('/', [ViajeController::class, 'index'])->name('reserva.index');

Route::get('viaje/reservaExitosa', [ViajeController::class, 'reservaExitosa']);

Route::get('viaje/obtenerOrigen/{id}', [ViajeController::class, 'obtenerOrigen']);

Route::post('viaje/reservar', [ViajeController::class, 'viajeMiTaxi']);

Route::post('viaje/imprimirTicket', [ViajeController::class, 'imprimirTicket']);

Route::get('viaje/obtenerDestinos', [DestinoController::class, 'index']);

Route::get('viaje/obtenerDestinoId/{id}', [DestinoController::class, 'obtenerDestinoId']);
