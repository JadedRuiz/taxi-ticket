<button type="button" class="d-none btnModalAsigViaje" data-bs-toggle="modal" data-bs-target="#modalAsigViaje"></button>
<div class="modal fade" id="modalAsigViaje" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">
                    Asignación de Vehiculo
                    <br>
                    <p class="card-title-desc">Aquí podrás asignar el vehiculo & operador que realizaran el viaje</p>
                </h1>
                <button type="button" class="btn-close btnModalClose" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row my-0">                    
                    <p class="col-12 my-0 txtTitle">Mis vehiculos</p>
                </div>
                <div class="lstVehiculos">
                    <?php if($vehiculos["ok"] && count($vehiculos["data"]) > 0): ?>
                        <?php $__currentLoopData = $vehiculos["data"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehiculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card col-12 mt-1 just mt-2">
                                <div class="row g-0">
                                    <div class="col-md-3 cont-img">
                                        <img src="<?php echo e(asset($vehiculo->path)); ?>" class="rounded-start img-fluid img-defualt">                               
                                    </div>
                                    <div class="col-md-9">
                                        <div class="card-body">
                                            <h5 class="card-title py-0 my-0"><?php echo e($vehiculo->vehiculo); ?></h5>
                                            <p class="card-text py-0 my-0"><?php echo e($vehiculo->marca); ?> (<?php echo e($vehiculo->modelo); ?>)</p>
                                            <div class="d-flex flex-column">
                                                <p class="card-text my-0">Operadores: </p>
                                                    <?php if(count($vehiculo->operadores) > 0): ?>
                                                        <div class="d-flex justify-content-between">
                                                            <select name="operadores" style="font-size: 12px" class="slcOperadores form-select">
                                                                <option value="0" selected>Seleccione un operador</option>
                                                                <?php $__currentLoopData = $vehiculo->operadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                                    <option value="<?php echo e($operador->id_vehiculo_operador); ?>">
                                                                        <?php echo e($operador->nombres); ?> <?php echo e($operador->apellidos); ?>

                                                                    </option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                            <button class="btn btn-sm btn-success btnAsignarVehiculo">
                                                                <i class="fa fa-floppy-o mx-2" aria-hidden="true"></i>
                                                            </button>
                                                        </div>                                                        
                                                    <?php else: ?>
                                                        <small class="text-danger">Este vehiculo no cuenta con operadores</small>
                                                    <?php endif; ?>
                                            </div>                        
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="card col-12 mt-1">
                            <div class="card-body text-center">
                                <p class="card-text">Aún no se han agregado vehiculos</p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\PC WHITE HORSE\OneDrive\Documentos\Jaded\Proyectos\Inge\Laravel\taxi-ticket\resources\views/components/modales/modal_asignar_vehiculo.blade.php ENDPATH**/ ?>