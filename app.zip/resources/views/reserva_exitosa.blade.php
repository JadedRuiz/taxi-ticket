<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Mi taxi</title>
    @vite(['public/sass/app.scss', 'public/sass/viaje.scss', 'public/js/app.js'])
</head>
<body>
    <p class="pantalla">Reserva exitosa</p>
</body>
</html>